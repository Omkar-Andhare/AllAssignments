package OOPsAssignment.Q3TravelBookingSystem.service;

public interface IJourneyOperations {
    public void bookTravel(String mode);

    public void checkStatus();

    public void cancelTravel();
}
