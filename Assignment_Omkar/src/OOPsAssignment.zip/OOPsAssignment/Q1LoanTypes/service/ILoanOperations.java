package OOPsAssignment.Q1LoanTypes.service;

public interface ILoanOperations {
    double calculateTotalPayable(double principle,int months);
}
